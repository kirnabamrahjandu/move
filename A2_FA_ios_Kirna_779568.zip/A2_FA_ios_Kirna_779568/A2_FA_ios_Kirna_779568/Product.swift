//
//  Product.swift
//  A2_FA_ios_Kirna_779568
//
//  Created by user165337 on 1/31/21.
//  Copyright © 2021 user165337. All rights reserved.
//

import Foundation
struct Product {
    
var ID : Int
var Name : String
var Description : String
var Price: Int
var Provider : String
}
